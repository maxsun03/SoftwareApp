package com.softengi.mobcomp.softwareengi_mobile.Utils;

/**
 * Listens for successful requests
 */
public interface SuccessListener {

    /**
     * Called when a request is successful
     */
    void successful();

}
