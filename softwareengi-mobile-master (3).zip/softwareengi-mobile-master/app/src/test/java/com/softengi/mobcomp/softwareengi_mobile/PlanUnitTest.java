package com.softengi.mobcomp.softwareengi_mobile;

import org.junit.Test;

/**
 * Testing for plans
 */
public class PlanUnitTest {

    @Test
    public void testTestValidatePlan() throws Exception {

    }

}
